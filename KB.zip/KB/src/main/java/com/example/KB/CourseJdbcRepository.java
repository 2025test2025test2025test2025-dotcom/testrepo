package com.example.KB;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CourseJdbcRepository {

    @Autowired
    private JdbcTemplate springJdbcTemplate;

    private static final String INSERT_QUERY =
            """
            INSERT INTO course (id, name, author)
            VALUES (?, ?, ?);
            """;

    private static final String DELETE_QUERY =
            """
            DELETE FROM course
            WHERE id = ?;
            """;

    private static final String SELECT_BY_ID_QUERY =
            """
            SELECT id, name, author
            FROM course
            WHERE id = ?;
            """;

    public void insert(Course course) {
        springJdbcTemplate.update(
                INSERT_QUERY,
                course.getId(), course.getName(), course.getAuthor()
        );
    }

    public void delete(long id) {
        springJdbcTemplate.update(DELETE_QUERY, id);
    }

    public Course findById(long id) {
        try {
            return springJdbcTemplate.queryForObject(
                    SELECT_BY_ID_QUERY,
                    new Object[]{id},
                    (rs, rowNum) -> new Course(
                            rs.getLong("id"),
                            rs.getString("name"),
                            rs.getString("author")
                    )
            );
        } catch (EmptyResultDataAccessException e) {
            // Возвращаем null, если курс не найден
            return null;
        }
    }

    public List<Course> findAll() {
        String sql = "SELECT id, name, author FROM course";

        return springJdbcTemplate.query(
                sql,
                (rs, rowNum) -> new Course(
                        rs.getLong("id"),
                        rs.getString("name"),
                        rs.getString("author")
                )
        );
    }
}
