package com.example.KB;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class CourseJdbcCommandLineRunner implements CommandLineRunner {
   @Autowired
   private CourseSpringDataJpaRepository repository;
   @Autowired
   private CourseJdbcRepository courseJdbcRepository;

    @Override
    public void run(String... args) throws Exception {
        courseJdbcRepository.insert(new Course(1, "Osman","Mirverdi"));
        courseJdbcRepository.insert(new Course(2, "Ali","Father"));
        courseJdbcRepository.insert(new Course(3, "Kenan","Baby"));
        courseJdbcRepository.insert(new Course(4, "Fidan","Girl"));
        courseJdbcRepository.insert(new Course(5, "Roksana","Syster"));
        courseJdbcRepository.delete(1);
        courseJdbcRepository.delete(2);
        courseJdbcRepository.insert(new Course(6, "King","Baby"));
        System.out.println(courseJdbcRepository.findById(1));
        System.out.println(courseJdbcRepository.findById(1));
        System.out.println(repository.findAll());
        System.out.println(repository.count());
        System.out.println(repository.findByName("Osman"));
        System.out.println(repository.findByAuthor("Fidan"));
    }
}