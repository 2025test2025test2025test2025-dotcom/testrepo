package com.example.KB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KbApplicationTests {

	@Test
	void contextLoads() {
	}

}
